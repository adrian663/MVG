package com.adrian.mvg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

public class Video extends AppCompatActivity {

    private VideoView abertura;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        abertura = findViewById(R.id.abertura);
        btnVoltar = findViewById(R.id.btnVoltar);

        Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.abertura);
        abertura.setVideoURI(caminho);
        abertura.start();

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    public void abrirVoltar(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
        abertura.stopPlayback();
    }

}