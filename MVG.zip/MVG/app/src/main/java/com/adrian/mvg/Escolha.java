package com.adrian.mvg;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class Escolha extends AppCompatActivity {

    private TextView resposta;
    private Button btnVideo, btnMusica;
    private WebView imagem2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);

        resposta = findViewById(R.id.resposta);
        btnVideo = findViewById(R.id.btnVideo);
        btnMusica = findViewById(R.id.btnMusica);
        imagem2 = findViewById(R.id.imagem2);

        String recebe =  getIntent().getStringExtra("dados");
        resposta.setText(recebe);

        WebSettings gif = imagem2.getSettings();
        gif.setJavaScriptEnabled(true);
        String caminho = "file:android_asset/Gif.gif";
        imagem2.loadUrl(caminho);

        btnVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVideo();
            }
        });

        btnMusica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMusica();
            }
        });


    }

    public void abrirVideo(){
       Intent janelav = new Intent(this, Video.class);
        startActivity(janelav);
    }

    public void abrirMusica(){
        Intent janelam= new Intent(this, Musica.class);
        startActivity(janelam);
    }

}